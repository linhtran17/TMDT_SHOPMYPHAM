package com.shopmypham.core.exception;
public class NotFoundException extends ApiException { public NotFoundException(String msg){ super(msg);} }
