package com.shopmypham.core.exception;
public class ApiException extends RuntimeException { public ApiException(String msg){ super(msg);} }
