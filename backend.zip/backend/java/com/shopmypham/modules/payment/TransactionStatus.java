package com.shopmypham.modules.payment;

public enum TransactionStatus {
  initiated, pending, success, failed, refunded
}
