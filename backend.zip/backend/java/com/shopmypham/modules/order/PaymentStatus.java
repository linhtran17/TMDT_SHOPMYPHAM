package com.shopmypham.modules.order;

public enum PaymentStatus {
  pending, paid, failed
}
