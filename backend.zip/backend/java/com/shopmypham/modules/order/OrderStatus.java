package com.shopmypham.modules.order;
public enum OrderStatus { pending, confirmed, processing, shipped, delivered, cancelled }
