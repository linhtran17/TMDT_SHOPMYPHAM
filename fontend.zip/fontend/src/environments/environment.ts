export const environment = {
  production: false,
  // đổi host/port theo BE của bạn
  apiBase: 'http://localhost:8080'
};
